'use strict';

const express = require('express')
const app = express()
const port = 3000

const crypto = require('crypto');
const url = require('url');
const ENC_KEY = crypto.randomBytes(12).toString('hex'); // set random encryption key
const IV = crypto.randomBytes(4).toString('hex');; // set random initialisation vector

const flag = "CSC{communication-is-key-even-when-all-you-provide-is-gibberish}"

var encrypt = ((val) => {
    let cipher = crypto.createCipheriv('des-ede3-cbc', ENC_KEY, IV);
    let encrypted = cipher.update(val, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
});

/**
 Inspect hexadecimal string two characters (1 byte) at a time
 from back to front.
*/
var checkAndRemovePadding = ((val) => {
    for(var i=1; i<=16; i++) {
        var hexed = i.toString(16);
        if(hexed.length < 2) hexed = "0"+hexed;
        
        if(val.substr(-2) == hexed) {
            for(var j=1; j<=i; j++) {
                if(val.substr(-2*j,2) != hexed) {
                    throw new Error("Invalid padding");   
                }
            }
            
            return val.substr(0,val.length-2*(j-1));
        }
    }
    throw new Error("Invalid padding");
})

var hex2ascii = ((hexx) => {
    var hex = hexx.toString();//force conversion
    var str = '';
    for (var i = 0; (i < hex.length && hex.substr(i, 2) !== '00'); i += 2)
        str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    return str;
});

var decrypt = ((encrypted) => {
    let decipher = crypto.createDecipheriv('des-ede3-cbc', ENC_KEY, IV);
    decipher.setAutoPadding(false);    
    let decrypted = decipher.update(encrypted, 'hex', 'hex');
    decrypted = decrypted + decipher.final('hex');
    
    // check padding ourself to throw the padding oracle error
    decrypted = checkAndRemovePadding(decrypted);
    
    return hex2ascii(decrypted);
});

app.get('/flag', function(req, res) {
    var parts = url.parse(req.url, true);
    var userid;
    var result = {"user": false, "error": "The flag is only available to administrators.", "flag": false}
    
    if(! parts.query.hasOwnProperty("user")) {
        result.error = "The user id should be specified as a GET parameter"
    } else {
        try {
            result.user = decrypt(parts.query.user); 
        } catch (e) {
            result.error = "User id could not be decrypted: "+e
        }

        if(result.user && result.user.indexOf("admin") > -1) {
            result.flag = flag;
            result.error = null;
        }
    }
    
    res.json(result);
});

app.get('/', function(req, res){ res.redirect(301, '/user') });

app.get('/user', function(req, res) {
    res.json(
        {
            "user": encrypt("delphi")
        }
    )
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))