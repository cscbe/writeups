#!/bin/python

# solution.py

from paddingoracle import BadPaddingException, PaddingOracle
import codecs
import requests
import socket
import time

class PadBuster(PaddingOracle):
    def __init__(self, **kwargs):
        super(PadBuster, self).__init__(**kwargs)
        self.session = requests.Session()
        self.wait = kwargs.get('wait', 2.0)

    def oracle(self, data, **kwargs):
        userid = codecs.encode(data, 'hex')

        while 1:
            try:
                request_url = 'http://localhost:3000/flag?user='+userid
                response = self.session.get(request_url,
                        stream=False, timeout=5)
                break
            except (socket.error, requests.exceptions.RequestException):
                logging.exception('Retrying request in %.2f seconds...',
                                  self.wait)
                time.sleep(self.wait)
                continue

        self.history.append(response)

        if ' Invalid padding' not in response.content:
            logging.debug('No padding exception raised on %r', userid)
            return

        raise BadPaddingException

if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(level=logging.DEBUG)

    padbuster = PadBuster()
    get_admin = padbuster.encrypt('admin', block_size=8)

    print('Encrypted: admin => %s' % (codecs.encode(get_admin, 'hex')))