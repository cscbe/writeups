#include <jni.h>
#include <string>
#include <android/log.h>

extern "C" JNIEXPORT jstring JNICALL
Java_be_dauntless_theultimatequestion_MainActivity_getVault(
        JNIEnv* env,
        jobject /* this */) {

    jstring jstr = env->NewStringUTF("This comes from jni.");
    jclass clazz = env->FindClass( "be/dauntless/theultimatequestion/MainActivity");
    jmethodID getString = env->GetStaticMethodID( clazz, "getResourceString", "(I)Ljava/lang/String;");


     // should be released but what a heck, it's a tutorial :)
    char buff[90000];
    const char* str;
    int pos = 0;
    int i = 0;
    int length = 2;
    for(i = 2; i<=138; i++)
    {
        jobject result = env->CallStaticObjectMethod(clazz, getString, i);
        str = env->GetStringUTFChars((jstring) result, NULL);
        //__android_log_print(ANDROID_LOG_DEBUG, "XXX", "Need to print : %s", str);

        memcpy(buff + pos, str, i);
        pos += i;
    }

    return env->NewStringUTF(buff);

}