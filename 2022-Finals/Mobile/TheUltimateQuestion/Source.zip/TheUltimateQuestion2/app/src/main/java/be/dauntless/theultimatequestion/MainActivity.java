package be.dauntless.theultimatequestion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;


import android.util.Base64;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;

import dalvik.system.InMemoryDexClassLoader;

import be.dauntless.theultimatequestion.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // Used to load the 'theultimatequestion' library on application startup.
    static {
        System.loadLibrary("theultimatequestion");
    }
    Class vault;
    Method verifier;
    public static String parts[];

    private ActivityMainBinding binding;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        parts = this.getResources().getStringArray(R.array.parts);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        this.findViewById(R.id.btnSubmit).setOnClickListener(this);

        String rawvault = this.getVault();
        byte[] data = Base64.decode(rawvault, Base64.DEFAULT);

        ByteBuffer bb = ByteBuffer.allocate(data.length);
        bb.put(data);
        bb.position(0);
        try{
            ClassLoader loader = new InMemoryDexClassLoader(bb, this.getClassLoader());
            vault = loader.loadClass("be.dauntless.theultimatequestion.Vault"); //ClassNotFoundException
            verifier = vault.getMethod("checkAnswer", String.class);

        }catch(Exception e){
            e.printStackTrace();
        }


    }

    public static String getResourceString(int l){
        for(int i = 0; i<200; i++)
        {
            if(MainActivity.parts[i].length() == l){
                return MainActivity.parts[i].split("=")[0];
            }
        }
        return "";
    }

    /**
     * A native method that is implemented by the 'theultimatequestion' native library,
     * which is packaged with this application.
     */
    public native String getVault();

    @Override
    public void onClick(View view) {
        String text = ((EditText) this.findViewById(R.id.txtAnswer)).getText().toString();
        try {
            String answer = (String) verifier.invoke(vault.newInstance(), text);
            Toast.makeText(this.getApplicationContext(), answer, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}