# Copyright 2018 Cisco Systems, Inc.
# All rights reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os
import socket
import base64, sys, re
import Crypto.Cipher.AES
from flask import Flask, request

app = Flask(__name__)


@app.route('/')
def index():
    return "CTF Gameserver v1.18b"

@app.route('/submitscore', methods=['GET', 'POST'])
def submitscore():

    if 'score' in request.form and 'name' in request.form:
        score = request.form.get('score')
        name = request.form.get('name')

        try:
            decryptedScore = decryptScore(score)
            cleanedScore = clean(decryptedScore)
            print("DecryptedScore: " + str(cleanedScore))

            if int(cleanedScore.strip()) > 9000:
                return "csc{next_time_i'll_fight_yamcha}"
            else:
                return "You're too weak. Kakarot won!"


        except Exception as err:
            print(f"Unexpected {err=}, {type(err)=}")
            return "Invalid score"
    else:
        return "CTF Gameserver v1.18b"


def decryptScore(score):

    password = base64.b64decode('o7DnoKFF3WcTc0kVX/gQkwsGlCND/m47wewY2BKHAFk=') # See rgbKey
    salt = base64.b64decode('8oR4fXPtcI35z0PEV7OfFQ==') # See rgbIV
    aes = Crypto.Cipher.AES.new(password, Crypto.Cipher.AES.MODE_CBC, salt)
    text = base64.b64decode(score)
    return aes.decrypt(text).decode('utf-16')

def clean(score):
    v = re.search("^(\d+)", score, re.IGNORECASE)
    if v:
        return v.group(1)
    else:
        raise Exception("Invalid score")